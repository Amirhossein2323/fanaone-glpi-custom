<?php
use Glpi\Plugin\Hook;

function plugin_init_persian_date() {
    global $PLUGIN_HOOKS;


    $PLUGIN_HOOKS['add_javascript']['persian_date'] = 'js/persian_date.js';
}

function plugin_version_persian_date() {
    return [
        'name'           => "Persian Date",
        'version'        => '1.0.0',
        'author'         => 'Your Name',
        'license'        => 'GPLv2+',
        'homepage'       => '',
        'minGlpiVersion' => '10.0.0'
    ];
}

function plugin_persian_date_check_prerequisites() {
    return true;
}

function plugin_persian_date_check_config() {
    return true;
}
