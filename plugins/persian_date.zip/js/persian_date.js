function loadScript(src, callback) {
  let script = document.createElement('script');
  script.src = src;
  script.onload = callback;
  document.head.appendChild(script);
}

loadScript('https://cdn.jsdelivr.net/npm/moment@2.29.4/moment.min.js', () => {
  loadScript('https://cdn.jsdelivr.net/npm/moment-jalaali@0.9.3/build/moment-jalaali.js', () => {
    convertTextNodesToPersianDate(document.body);
  });
});
function convertTextNodesToPersianDate(root) {
  const walker = document.createTreeWalker(
    root,
    NodeFilter.SHOW_TEXT,
    null,
    false
  );

  const dateRegex = /\b\d{4}[-/]\d{1,2}[-/]\d{1,2}\b/g;

  let node;
  while (node = walker.nextNode()) {
    let text = node.nodeValue.trim();
    let matches = text.match(dateRegex);
    if (matches) {
      let newText = text;

      matches.forEach(dateStr => {
        let m = moment(dateStr, ["YYYY-MM-DD", "YYYY/MM/DD"], true);
        if (m.isValid()) {
          let persianDate = m.format('jYYYY/jMM/jDD');
          newText = newText.replace(dateStr, persianDate);
        }
      });
      if (newText !== text) {
        node.nodeValue = newText;
      }
    }
  }
}
